defmodule Mix.Tasks.Elilang.New do
  @moduledoc """
  New project generator:
  
      mix elilang.new my_app
  """

  use Mix.Task

  @template_dir Path.join(:code.priv_dir(:elilang), "templates/new")

  def run([app_name]) do
    Mix.shell().info("Creating Elilang project: #{app_name}")
    
    files = %{
      "router.ex" => "lib/#{app_name}/router.ex",
      "controller.ex" => "lib/#{app_name}/controllers/home.ex"
    }

    for {src, dst} <- files do
      content = EEx.eval_file(Path.join(@template_dir, src), app_name: app_name)
      Mix.Generator.create_file(dst, content)
    end
  end
end