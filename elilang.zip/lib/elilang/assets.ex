defmodule Elilang.Assets do
  @moduledoc """
  Управление ассетами через Go-сборщик
  """
  @assets_dir "assets/build"

  def build do
    System.cmd("go", ["run", "builder.go"], cd: @assets_dir)
  end

  def watch do
    # Простой вотчер на Elixir без зависимостей
    pid = spawn(fn -> 
      FileSystem.subscribe(@assets_dir)
      loop()
    end)
    {:ok, pid}
  end

  defp loop do
    receive do
      _event -> 
        build()
        loop()
    end
  end
end