defmodule Elilang.Template do
  @moduledoc """
  Simple rendering of EEx templates:
  
      Template.render("index.html", %{title: "Hello"})
  """

  @templates_dir "priv/templates/"

  def render(template, assigns) do
    template
    |> template_path()
    |> EEx.eval_file(assigns: assigns)
  end

  defp template_path(name) do
    Path.join(@templates_dir, name)
  end
end