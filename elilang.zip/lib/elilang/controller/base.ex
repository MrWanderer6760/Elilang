defmodule Elilang.Controller.Base do
  @moduledoc """
  Basic controller:
  
      defmodule MyController do
        use Elilang.Controller.Base
        
        def hello(conn, _params) do
          json(conn, %{message: "Hello"})
        end
      end
  """

  defmacro __using__(_opts) do
    quote do
      import Plug.Conn

      @doc "Render HTML template"
      def render(conn, template, assigns \\ []) do
        html = Elilang.Template.render(template, assigns)
        send_resp(conn, 200, html)
      end

      @doc "Sending JSON"
      def json(conn, data) do
        conn
        |> put_resp_content_type("application/json")
        |> send_resp(200, Jason.encode!(data))
      end
    end
  end
end