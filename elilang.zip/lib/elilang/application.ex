defmodule Elilang.Application do
  @moduledoc false
  use Application

  def start(_type, _args) do
    children = [
      {Elilang.Assets, []},
      {Plug.Cowboy, scheme: :http, plug: init_router(), options: [port: port()]}
    ]

    Supervisor.start_link(children, strategy: :one_for_one)
  end

  defp init_router do
    # Automatically loads the router from the main application
    Module.concat(Application.get_env(:elilang, :app_module), "Router")
  end

  defp port, do: Application.get_env(:elilang, :port, 4000)
end