defmodule Elilang.Router.DSL do
  @moduledoc """
  Simple DSL for routing:
  
      get "/hello", MyController, :hello
  """

  defmacro __using__(_opts) do
    quote do
      use Plug.Router
      import Plug.Conn

      plug(:match)
      plug(:dispatch)

      @before_compile unquote(__MODULE__)
    end
  end

  defmacro __before_compile__(_env) do
    quote do
      def start(port \\ 4000) do
        Plug.Cowboy.http(__MODULE__, [], port: port)
      end
    end
  end

  defmacro get(path, controller, action) do
    quote bind_quoted: [path: path, controller: controller, action: action] do
      match path, via: :get do
        apply(controller, action, [conn, conn.params])
      end
    end
  end
end