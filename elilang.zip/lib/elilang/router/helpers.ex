defmodule Elilang.Router.Helpers do
  @moduledoc """
  Generating URL paths
  """
  def path(controller, action, opts \\ []) do
    router = Module.concat(Application.get_env(:elilang, :app_module), "Router")
    apply(router, :path_for, [controller, action, opts])
  end

  def url(controller, action, opts \\ []) do
    base_url = Application.get_env(:elilang, :base_url, "http://localhost:4000")
    base_url <> path(controller, action, opts)
  end
end