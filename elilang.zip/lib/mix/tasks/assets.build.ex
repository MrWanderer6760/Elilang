defmodule Mix.Tasks.Assets.Build do
  @moduledoc """
  Building assets via Go:
  
      mix assets.build
  """

  use Mix.Task

  def run(_) do
    System.cmd("go", ["run", "build/builder.go"], cd: "assets")
  end
end