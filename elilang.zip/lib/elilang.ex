defmodule Elilang do
  @moduledoc """
  Минималистичный веб-фреймворк для Termux.
  Пример использования:
  
      defmodule MyApp do
        use Elilang
        
        get "/" do
          conn |> render("index.html", %{title: "Hello"})
        end
      end
  """
  
  defmacro __using__(_opts) do
    quote do
      use Elilang.Router.DSL
      use Elilang.Controller.Base
      import Elilang.Helpers
    end
  end
end