package main

import (
	"os/exec"
	"log"
)

func main() {
	// CSS
	if err := exec.Command("sass", "scss/app.scss", "../priv/static/css/app.css").Run(); err != nil {
		log.Println("CSS error (install sass with 'pkg install sass'):", err)
	}

	// JS
	if err := exec.Command("esbuild", 
		"js/app.js", 
		"--minify",
		"--bundle",
		"--outfile=../priv/static/js/app.js").Run(); err != nil {
		log.Println("JS error (install esbuild with 'npm i -g esbuild'):", err)
	}
}