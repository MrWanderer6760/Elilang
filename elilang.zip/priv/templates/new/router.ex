defmodule <%= @app_name %>.Router do
  @moduledoc false
  use Elilang.Router.DSL

  # Example route
  get "/", <%= @app_name %>.Controllers.Home, :index
end