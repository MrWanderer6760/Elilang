defmodule <%= @app_name %>.Controllers.Home do
  @moduledoc false
  use Elilang.Controller.Base

  def index(conn, _params) do
    render(conn, "index.html", %{title: "Welcome"})
  end
end