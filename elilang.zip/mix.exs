def deps do
  [
    {:elilang, github: "MrWanderer6760/elilang/elilang.zip"}
  ]
end